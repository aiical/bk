angular.module("test", [ 'directives' ])
.controller("testCtrl",
		[ '$scope', function($scope) {

			$scope.time1 = "2016/01/03 21:00";
			$scope.time2 = "2016/01/03 22:00";

		} ]);
